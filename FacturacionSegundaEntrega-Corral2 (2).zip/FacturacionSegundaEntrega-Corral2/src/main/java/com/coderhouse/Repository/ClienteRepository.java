//aca uso los metodos de jpa (finbyid, findall, deletebyid,etc)

package com.coderhouse.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.coderhouse.models.Cliente;
@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Integer>{

}
