package com.coderhouse.Service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.coderhouse.Repository.ClienteRepository;
import com.coderhouse.models.Cliente;


@Service
public class ClienteService {
	@Autowired
	public ClienteRepository clienteRepository;
	
	public List<Cliente> listarClientes(){
		return clienteRepository.findAll();
	}

	@SuppressWarnings("null")
	public Cliente mostrarClientePorId(Integer dni) {
		return clienteRepository.findById(dni).orElse(null);
		
	}
	
    @SuppressWarnings("null")
	public Cliente agregarCliente(Cliente cliente) {
    	return clienteRepository.save(cliente);

    }

}
