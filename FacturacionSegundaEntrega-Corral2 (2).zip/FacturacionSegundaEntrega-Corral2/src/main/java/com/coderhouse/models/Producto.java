package com.coderhouse.models;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Schema(description="Modelo de Productos")

@Entity
@Table(name = "producto")
public class Producto {
	
	@Schema(description ="Id del producto",requiredMode= Schema.RequiredMode.REQUIRED, example ="idProducto=1")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	
	@Schema(description = "Nombre del producto", requiredMode=Schema.RequiredMode.REQUIRED, example = "Guitarra")
    private String nombre;
	
	@Schema(description = "Descripcion del producto", requiredMode=Schema.RequiredMode.REQUIRED, example = "instrumento de 5 cuerdas")
    private double precio;
	
	@Schema(description = "Cantidad por producto", requiredMode=Schema.RequiredMode.REQUIRED, example = "1")
    private int cantidad;


    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }



    public Producto(Long id, String nombre, double precio, int cantidad) {
        super();
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    public Producto() {
        super();
        // TODO Auto-generated constructor stub
    }
}

