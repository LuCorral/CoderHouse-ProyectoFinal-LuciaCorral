package com.coderhouse.models;

import java.time.LocalDate;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Schema(description="modelo de ventas")  
@Entity
@Table(name = "ventas")
public class Ventas {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Schema(description="id cliente asociado a la venta")
    @ManyToOne
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    @Schema(description="id producto asociado a la venta")    
    @ManyToOne
    @JoinColumn(name = "producto_id")
    private Producto producto;
    
    @Schema(description="id comprobante asociado a la venta")    
    @ManyToOne
    @JoinColumn(name = "comprobante_id")
    private Comprobante comprobante;

    private LocalDate fecha;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }


    

    public Producto getProducto() {
		return producto;
	}

	public void setProducto(Producto producto) {
		this.producto = producto;
	}

	public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public Ventas(Long id, Cliente cliente, List<Producto> productos, LocalDate fecha) {
        super();
        this.id = id;
        this.cliente = cliente;
        this.fecha = fecha;
    }

    public Ventas() {
        super();
        // TODO Auto-generated constructor stub
    }
}







