package com.coderhouse.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coderhouse.Repository.ClienteRepository;
import com.coderhouse.Repository.ComprobanteRepository;
import com.coderhouse.Repository.VentasRepository;
import com.coderhouse.models.Cliente;
import com.coderhouse.models.Comprobante;
import com.coderhouse.models.Ventas;

@Service
public class ComprobanteService {
	@Autowired
	private ComprobanteRepository comprobanteRepository;
	@Autowired
	private ClienteRepository clienteRepository;
	@Autowired
	private VentasRepository ventasRepository;
	@Autowired
	private FechaService fechaService;

	public List<Comprobante> listarComprobantes(){
		List<Comprobante> listadoComprobantes = comprobanteRepository.findAll();
		return listadoComprobantes;
	}
		

	@SuppressWarnings("null")
	public Comprobante agregarComprobante(Comprobante comprobante) {
		Cliente cliente = clienteRepository.findById(comprobante.getCliente().getDni()).orElseThrow(IllegalArgumentException::new);
		comprobante.setCliente(cliente);
		Ventas ventas = ventasRepository.findById(comprobante.getVentas().getId()).orElseThrow(IllegalArgumentException::new);
	    comprobante.setVentas(ventas);
	    comprobante.setImporteVenta(ventas.getImporteTotal());
	    comprobante.setFechaVenta(fechaService.obtenerFecha());
	    return comprobanteRepository.save(comprobante);	  
	}
	
	@SuppressWarnings("null")
	public Comprobante mostrarComprobante(Long id) {
		Comprobante comprobante = comprobanteRepository.findById(id).orElse(null);
		return comprobante;
	}
	
}
