package com.coderhouse.models;


import java.time.LocalDateTime;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "comprobante")
@Schema(description = "Modelo de Comprobante de Venta")
public class Comprobante {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private LocalDateTime fechaVenta;
    
    private Cliente cliente;
   
	private double importeVenta;

    @OneToOne(mappedBy = "comprobante")
    private Ventas ventas;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDateTime getFechaVenta() {
		return fechaVenta;
	}

	public void setFechaVenta(LocalDateTime localDateTime) {
		this.fechaVenta = localDateTime;
		
	}
	
    public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public double getImporteVenta() {
		return importeVenta;
	}

	public void setImporteVenta(double importeVenta) {
		this.importeVenta = importeVenta;
	}

	public Comprobante(Long id, LocalDateTime fechaVenta, Cliente cliente, double importeVenta, Ventas ventas) {
		super();
		this.id = id;
		this.fechaVenta = fechaVenta;
		this.cliente = cliente;
		this.importeVenta = importeVenta;
		this.ventas = ventas;
	}

	public Comprobante() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Ventas getVentas() {
		return ventas;
	}

	public void setVentas(Ventas ventas) {
		this.ventas = ventas;
	}




}


    

    
   