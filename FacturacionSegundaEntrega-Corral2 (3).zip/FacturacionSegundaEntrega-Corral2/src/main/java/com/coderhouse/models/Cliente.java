package com.coderhouse.models;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;


@Schema(description="Modelo de Clientes")
@Entity
@Table(name = "cliente")
public class Cliente {
	
	@Schema(description ="DNI del Cliente",requiredMode= Schema.RequiredMode.REQUIRED, example ="40807808")
    @Id
	@Column(name = "id")
    private Integer dni;
	
	@Schema(description ="nombre del Cliente",requiredMode= Schema.RequiredMode.REQUIRED, example ="Lucia")
	@Column(name = "nombre")
	private String nombre;
	
	@Schema(description ="apellido del Cliente",requiredMode= Schema.RequiredMode.REQUIRED, example ="Corral")
	@Column(name = "apellido")
	private String apellido;
	
	@Schema(description ="Email del Cliente",requiredMode= Schema.RequiredMode.REQUIRED, example ="lucorral@gmail.com")
	@Column(name = "email")
	private String email;
	
	

	
	@Schema(description="Lista de Ventas asociadas al cliente")
    @OneToMany(mappedBy = "cliente", cascade = CascadeType.ALL)
    private List<Ventas> ventas;


    public Integer getDni() {
		return dni;
	}

	public void setDni(Integer dni) {
		this.dni = dni;
	}

	public List<Ventas> getVentas() {
        return ventas;
    }

    public void setVentas(List<Ventas> ventas) {
        this.ventas = ventas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Cliente() {
        super();
     // TODO Auto-generated constructor stub
    }

	public Cliente(Integer dni, String nombre, String apellido, String email, List<Ventas> ventas) {
		this.dni = dni;
		this.nombre = nombre;
		this.apellido = apellido;
		this.email = email;
		this.ventas = ventas;
	}


}





