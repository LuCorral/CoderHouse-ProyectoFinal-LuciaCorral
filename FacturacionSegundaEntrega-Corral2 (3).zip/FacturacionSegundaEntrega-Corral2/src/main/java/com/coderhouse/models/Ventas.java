package com.coderhouse.models;

import java.time.LocalDateTime;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Schema(description="modelo de ventas")  
@Entity
@Table(name = "ventas")
public class Ventas {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private LocalDateTime fechaVenta;
    
    private Integer totalProductos;
    
    private double importeTotal;

    @Schema(description="cliente asociado a la venta")
    private Cliente cliente;

    @Schema(description="Lista de productos asociados a la venta")    
    @OneToMany
    @JoinColumn(name = "ventas")
    private List<Producto> producto;
    
    @Schema(description="id comprobante asociado a la venta")    
    @OneToOne
    @JoinColumn(name = "comprobante_id")
    private Comprobante comprobante;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }


    public LocalDateTime getFechaVenta() {
		return fechaVenta;
	}

	public void setFechaVenta(LocalDateTime fechaVenta) {
		this.fechaVenta = fechaVenta;
	}

	public Integer getTotalProductos() {
		return totalProductos;
	}

	public void setTotalProductos(Integer totalProductos) {
		this.totalProductos = totalProductos;
	}

	public double getImporteTotal() {
		return importeTotal;
	}

	public void setImporteTotal(double importeTotal) {
		this.importeTotal = importeTotal;
	}

	public List<Producto> getProducto() {
		return producto;
	}

	public void setProducto(List<Producto> producto) {
		this.producto = producto;
	}

	public Comprobante getComprobante() {
		return comprobante;
	}

	public void setComprobante(Comprobante comprobante) {
		this.comprobante = comprobante;
	}


    public Ventas(Long id, LocalDateTime fechaVenta, Integer totalProductos, double importeTotal, Cliente cliente,
			List<Producto> producto, Comprobante comprobante) {
		super();
		this.id = id;
		this.fechaVenta = fechaVenta;
		this.totalProductos = totalProductos;
		this.importeTotal = importeTotal;
		this.cliente = cliente;
		this.producto = producto;
		this.comprobante = comprobante;
	}

	public Ventas() {
        super();
        // TODO Auto-generated constructor stub
    }
}







