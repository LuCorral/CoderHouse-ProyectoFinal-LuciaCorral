package com.coderhouse.models;


import java.time.LocalDateTime;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "comprobante")
@Schema(description = "Modelo de Comprobante de Venta")
public class Comprobante {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private LocalDateTime fechaVenta;
    
    @ManyToOne
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;
   
	private double importeVenta;
	
    @OneToMany(mappedBy = "comprobante", cascade = CascadeType.ALL)
    private List<Ventas> ventas; // Lista de líneas de ventas asociadas al comprobante

	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDateTime getFechaVenta() {
		return fechaVenta;
	}

	public void setFechaVenta(LocalDateTime localDateTime) {
		this.fechaVenta = localDateTime;
		
	}
	
    public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public double getImporteVenta() {
		return importeVenta;
	}

	public void setImporteVenta(double importeVenta) {
		this.importeVenta = importeVenta;
	}


	public List<Ventas> getVentas() {
		return ventas;
	}

	public void setVentas(List<Ventas> ventas) {
		this.ventas = ventas;
	}

	
	
	public Comprobante(Long id, LocalDateTime fechaVenta, Cliente cliente, double importeVenta, List<Ventas> ventas) {
		super();
		this.id = id;
		this.fechaVenta = fechaVenta;
		this.cliente = cliente;
		this.importeVenta = importeVenta;
		this.ventas = ventas;
	}

	public Comprobante() {
		super();
		// TODO Auto-generated constructor stub
	}





}


    

    
   