package com.coderhouse.models;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Schema(description="modelo de ventas")  
@Entity
@Table(name = "ventas")
public class Ventas {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
        
    private Integer totalProductos;
    
    private double importeTotal;

    @Schema(description="cliente asociado a la venta")
    @ManyToOne
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    @Schema(description="Lista de productos asociados a la venta")    
    @OneToMany(mappedBy = "ventas", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<Producto> productos = new ArrayList<>();
    
    @ManyToOne
    @JoinColumn(name = "comprobante_id")
    private Comprobante comprobante; // Referencia al comprobante al que pertenece esta línea de venta

    


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }


	public Integer getTotalProductos() {
		return totalProductos;
	}

	public void setTotalProductos(Integer totalProductos) {
		this.totalProductos = totalProductos;
	}

	public double getImporteTotal() {
		return importeTotal;
	}

	public void setImporteTotal(double importeTotal) {
		this.importeTotal = importeTotal;
	}


	public List<Producto> getProductos() {
		return productos;
	}

	public void setProductos(List<Producto> productos) {
		this.productos = productos;
	}




	public Comprobante getComprobante() {
		return comprobante;
	}

	public Ventas(Long id, Integer totalProductos, double importeTotal, Cliente cliente, List<Producto> productos,
			Comprobante comprobante) {
		super();
		this.id = id;
		this.totalProductos = totalProductos;
		this.importeTotal = importeTotal;
		this.cliente = cliente;
		this.productos = productos;
		this.comprobante = comprobante;
	}

	public void setComprobante(Comprobante comprobante) {
		this.comprobante = comprobante;
	}

	public Ventas() {
        super();
        // TODO Auto-generated constructor stub
    }
}







