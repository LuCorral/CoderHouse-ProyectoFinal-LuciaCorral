package com.coderhouse.dto;


import java.util.Map;

public class VentasRequestDTO {
    private Integer idCliente;
    private Map<Long, Integer> productosCantidad;

    // Getters y Setters
    public Integer getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Integer idCliente) {
        this.idCliente = idCliente;
    }

    public Map<Long, Integer> getProductosCantidad() {
        return productosCantidad;
    }

    public void setProductosCantidad(Map<Long, Integer> productosCantidad) {
        this.productosCantidad = productosCantidad;
    }
}