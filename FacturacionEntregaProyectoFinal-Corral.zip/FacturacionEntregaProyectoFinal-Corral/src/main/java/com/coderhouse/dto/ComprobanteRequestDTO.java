package com.coderhouse.dto;

public class ComprobanteRequestDTO {
    private Integer dniCliente;

    // Constructor, getters, and setters
    public ComprobanteRequestDTO() {}

    public ComprobanteRequestDTO(Integer dniCliente) {
        this.dniCliente = dniCliente;
    }

    public Integer getDniCliente() {
        return dniCliente;
    }

    public void setDniCliente(Integer dniCliente) {
        this.dniCliente = dniCliente;
    }
}
