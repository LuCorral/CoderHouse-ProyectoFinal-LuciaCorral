package com.coderhouse.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import org.springframework.web.client.RestTemplate;




@Service
public class FechaService {
	
    private final static String API_URL = "http://worldclockapi.com/api/json/utc/now";

    public LocalDateTime obtenerFecha() {
    	LocalDateTime fechaActual;
        try {
            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<String> response = restTemplate.getForEntity(API_URL, String.class);
            String fecha = response.getBody();
            fechaActual= LocalDateTime.parse(fecha, DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'"));
            return fechaActual;
        } catch (Exception e) {
	

            fechaActual= LocalDateTime.now();
            return fechaActual; // si falla uso lo hago de manewra local
        }
    }



}
