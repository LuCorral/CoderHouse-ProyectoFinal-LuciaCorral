package com.coderhouse.Service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coderhouse.Repository.ClienteRepository;
import com.coderhouse.Repository.ComprobanteRepository;

import com.coderhouse.models.Cliente;
import com.coderhouse.models.Comprobante;
import com.coderhouse.models.Ventas;

@Service
public class ComprobanteService {
	@Autowired
	private ComprobanteRepository comprobanteRepository;
	@Autowired
	private ClienteRepository clienteRepository;
	
	@Autowired
	private VentasService ventasService;

	@Autowired
	private FechaService fechaService;

	public List<Comprobante> listarComprobantes(){
		List<Comprobante> listadoComprobantes = comprobanteRepository.findAll();
		return listadoComprobantes;
	}
		

    @SuppressWarnings("null")
	public Comprobante agregarComprobante(Comprobante comprobante) {
        // Paso 1: Obtener el cliente asociado al comprobante
        Cliente cliente = clienteRepository.findById(comprobante.getCliente().getDni())
                .orElseThrow(() -> new IllegalArgumentException("Cliente no encontrado"));
        comprobante.setCliente(cliente);

        // Paso 2: Obtener el DNI del cliente para buscar las ventas asociadas
        Integer dniCliente = cliente.getDni();
        
        // Paso 3: Obtener las ventas asociadas al cliente por su DNI
        List<Ventas> ventasCliente = ventasService.obtenerVentasPorDNI(dniCliente);
        if (ventasCliente != null && !ventasCliente.isEmpty()) {
            // Paso 4: Asignar las ventas al comprobante
            comprobante.setVentas(ventasCliente);

            // Paso 4: Calcular el importe total del comprobante sumando los importes de cada venta
            double importeTotal = ventasCliente.stream().mapToDouble(Ventas::getImporteTotal).sum();
            comprobante.setImporteVenta(importeTotal);
        } else {
            throw new IllegalArgumentException("No se encontraron ventas para el cliente asociado al comprobante");
        }

        // Paso 5: Obtener la fecha actual o la fecha de la API
        LocalDateTime fechaVenta = fechaService.obtenerFecha();
        comprobante.setFechaVenta(fechaVenta);

        // Paso 6: Guardar el comprobante en el repositorio
        return comprobanteRepository.save(comprobante);
    }

    @SuppressWarnings("null")
	public Comprobante mostrarComprobante(Long id) {
        return comprobanteRepository.findById(id).orElse(null);
    }
}
	

