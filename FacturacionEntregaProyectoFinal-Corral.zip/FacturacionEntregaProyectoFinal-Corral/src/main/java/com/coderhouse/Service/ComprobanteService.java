package com.coderhouse.Service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coderhouse.Repository.ClienteRepository;
import com.coderhouse.Repository.ComprobanteRepository;

import com.coderhouse.models.Cliente;
import com.coderhouse.models.Comprobante;
import com.coderhouse.models.Ventas;

@Service
public class ComprobanteService {
	@Autowired
	private ComprobanteRepository comprobanteRepository;
	@Autowired
	private ClienteRepository clienteRepository;
	
	@Autowired
	private VentasService ventasService;

	@Autowired
	private FechaService fechaService;

	public List<Comprobante> listarComprobantes(){
		List<Comprobante> listadoComprobantes = comprobanteRepository.findAll();
		return listadoComprobantes;
	}
	
	
    @SuppressWarnings("null")
	public Comprobante agregarComprobante(Integer dniCliente) {
        // Obtener el cliente por su DNI
        Cliente cliente = clienteRepository.findById(dniCliente)
                .orElseThrow(() -> new IllegalArgumentException("Cliente no encontrado"));

        // Obtener las ventas asociadas al cliente
        List<Ventas> ventasCliente = ventasService.obtenerVentasPorDNI(dniCliente);
        if (ventasCliente == null || ventasCliente.isEmpty()) {
            throw new IllegalArgumentException("No se encontraron ventas para el cliente asociado al comprobante");
        }

        // Crear el comprobante y asignar los datos necesarios
        Comprobante comprobante = new Comprobante();
        comprobante.setCliente(cliente);
        comprobante.setVentas(ventasCliente);

        // Calcular el importe total del comprobante sumando los importes de cada venta
        double importeTotal = ventasCliente.stream().mapToDouble(Ventas::getImporteTotal).sum();
        comprobante.setImporteVenta(importeTotal);

        // Obtener la fecha actual o la fecha de la API
        LocalDateTime fechaVenta = fechaService.obtenerFecha();
        comprobante.setFechaVenta(fechaVenta);

        // Guardar el comprobante en el repositorio
        return comprobanteRepository.save(comprobante);
    }

    @SuppressWarnings("null")
	public Comprobante mostrarComprobante(Long id) {
        return comprobanteRepository.findById(id).orElse(null);
    }
		


}
	

