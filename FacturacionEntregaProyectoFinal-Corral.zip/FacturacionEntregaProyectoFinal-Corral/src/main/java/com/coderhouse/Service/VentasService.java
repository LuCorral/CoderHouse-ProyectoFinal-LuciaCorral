package com.coderhouse.Service;

import java.util.List;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.coderhouse.Repository.ClienteRepository;
import com.coderhouse.Repository.VentasRepository;

import com.coderhouse.models.Ventas;



@Service
public class VentasService {
	@Autowired VentasRepository ventasRepository;
	@Autowired ClienteRepository clienteRepository;
	
	public List<Ventas> listarVentas(){
		return ventasRepository.findAll();
	}


	@SuppressWarnings("null")

	public Ventas agregarVenta(Ventas venta) {
    	return ventasRepository.save(venta);
    }
	
    @SuppressWarnings("null")

	public Ventas editarVentaPorId(Long id, Ventas ventas) {
    	try {
    		if(ventasRepository.existsById(id)){
    			ventas.setId(id);
    			return ventasRepository.save(ventas);
    		}
    	}catch(EmptyResultDataAccessException e) {
    		return null;
    		}
    	return null;
	
    }
    
    public List<Ventas> obtenerVentasPorDNI(Integer dni) {
        // Obtener todas las ventas del repositorio
        List<Ventas> todasLasVentas = ventasRepository.findAll();

        // Filtrar las ventas del cliente por su número de DNI
        List<Ventas> lineaVentasDelCliente = todasLasVentas.stream()
                .filter(venta -> venta.getCliente().getDni().equals(dni))
                .collect(Collectors.toList());

        return lineaVentasDelCliente;
    }
}
