package com.coderhouse.config;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.servers.Server;

@Configuration
public class OpenApiConfig {	//http://localhost:8080/swagger-ui/index.html#/
	
	@Bean
	OpenAPI customOpenAPI (){
		return new OpenAPI()
				.info(new Info()
						.title("API REST Full JAVA Coder House")
						.version("1.0.0")
						.description("La API REST proporciona endpoints para administrar clientes, productos y ventas. Permite realizar"
								+"operaciones CRUD tanto para clientes,como para productos y ventas. La api esta documentada usando"
								+ "Swagger")
						.contact(new Contact()
								.name("Lucia Corral")
								.email("lucorral8@gmail.com"))
						.license(new License()
								.name("Licencia")
								)
						)
				.servers(List.of(new Server()
						.url("http://localhost:8080")
						.description("Servidor Local"))
						);
		
	}
	

}
