package com.coderhouse.Controllers;


import java.util.ArrayList;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.coderhouse.Repository.VentasRepository;
import com.coderhouse.Service.ClienteService;
import com.coderhouse.Service.ComprobanteService;
import com.coderhouse.Service.ProductoService;
import com.coderhouse.Service.VentasService;
import com.coderhouse.dto.VentasRequestDTO;
import com.coderhouse.models.Cliente;
import com.coderhouse.models.Producto;
import com.coderhouse.models.Ventas;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;



@RestController

@RequestMapping("/Ventas")
@Tag(name = "Gestion de Ventas", description = "Endpoints para gestionar ventas")
public class VentasController {
	@Autowired
	public VentasService ventasService;
	@Autowired
	public VentasRepository ventasRepository;
	@Autowired
	public ProductoService productoService;
	@Autowired
	public ComprobanteService comprobanteService;
	@Autowired
	public ClienteService clienteService;
	
	@Operation(summary="obtener una lista de las ventas realizadas")
	@GetMapping(value="/", produces= {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<List<Ventas>> listarVentas(){
		try {
			List<Ventas>ventas =ventasService.listarVentas();
			return new ResponseEntity<>(ventas, HttpStatus.OK); //ccodigo 200
			}catch (Exception e) {
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);//errorr 500
			}
	}
	

	


	@Operation(summary="agregar una nueva venta")
	@PostMapping(value = "/agregar", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Ventas> agregarVenta(@RequestBody VentasRequestDTO ventaRequest) {
        // Obtener el DNI del cliente 
        Integer idCliente = ventaRequest.getIdCliente();
        if (idCliente == null) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Retorna un error si no se proporciona el DNI del cliente en el JSON
        }

        // Obtener el cliente asociado al DNI
        Cliente cliente = clienteService.mostrarClientePorId(idCliente);
        if (cliente == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Retornar un error si el cliente no existe
        }

        Map<Long, Integer> productosCantidad = ventaRequest.getProductosCantidad();
        if (productosCantidad == null || productosCantidad.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        List<Producto> productosSeleccionados = new ArrayList<>();
        double importeTotal = 0.0;
        int totalProductos = 0;

        for (Map.Entry<Long, Integer> entry : productosCantidad.entrySet()) {
            Long idProducto = entry.getKey();
            Integer cantidad = entry.getValue();

            Producto producto = productoService.mostrarProductoPorId(idProducto);
            if (producto != null && cantidad != null && cantidad > 0) {
                double importeParcial = producto.getPrecio() * cantidad;
                producto.setCantidad(producto.getCantidad() - cantidad);
                productosSeleccionados.add(producto);
                importeTotal += importeParcial;
                totalProductos += cantidad;
            } else {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
        }

        Ventas venta = new Ventas();
        venta.setCliente(cliente);
        venta.setTotalProductos(totalProductos);
        venta.setImporteTotal(importeTotal);

        // Guardar la venta para obtener su ID y poder asignarla a los productos
        Ventas nuevaVenta = ventasService.agregarVenta(venta);

        // Asignar la venta a los productos y actualizar la cantidad en la base de datos
        for (Producto producto : productosSeleccionados) {
            producto.setVentas(nuevaVenta);
            productoService.actualizarProducto(producto);
        }

        // Actualizar la venta con los productos asignados
        nuevaVenta.setProductos(productosSeleccionados);

        return new ResponseEntity<>(nuevaVenta, HttpStatus.CREATED);
    }
}
